"use client";
import React from "react";
export function PricingSection() {
  return <section className="py-16"><h2 className="text-2xl font-bold text-center">Pricing Plans</h2></section>;
}