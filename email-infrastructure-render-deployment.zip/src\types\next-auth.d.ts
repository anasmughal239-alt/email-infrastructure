import { Role, SubscriptionStatus } from '@prisma/client'
import NextAuth from 'next-auth'

declare module 'next-auth' {
  interface Session {
    user: {
      id: string
      email: string
      name?: string | null
      role: Role
      subscriptionStatus: SubscriptionStatus
    }
  }

  interface User {
    id: string
    email: string
    name?: string | null
    role: Role
    subscriptionStatus: SubscriptionStatus
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    role: Role
    subscriptionStatus: SubscriptionStatus
  }
}